#!/usr/bin/env python
# coding: utf-8

# In[10]:


from pymongo import MongoClient
from bson.objectid import ObjectId
from pymongo.collection import Collection

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """
    
    def __init__(self):
        # Initializing the MongoClient. This helps to
        # access the MongoDB databases and collections
        self.client = MongoClient('mongodb://localhost:31353', username='aacuser', password='password6')
        self.database = self.client['AAC']
        
    def close_connection(self):
        self.client.close()

 # Complete this create method to implement the C in CRUD
    def create(self, data):
        if data:
            self.database.animals.insert_one(data)  # data should be dictionary
        else:
            raise ValueError("Nothing to save, because data parameter is empty")

# Create method to implement the R in CRUD
    def read(self, readData=None):
        if readData:
            data = self.database.animals.find(readData, {"_id": False})
        else:
            data = self.database.animals.find({}, {"_id": False})
        return data
    
# Create method to implement the U in CRUD
    def update(self, query, newData):
        if newData:
            changeData = self.database.animals.update_many(query, {"$set": newData})
            print("Successfully updated to: ", newData)
            return changeData.modified_count > 0
        else:
            print("Nothing to update, newData is empty")
            return False

# Create method to implement the D in CRUD
    def delete(self, remove):
        if remove:
            delete_result = self.database.animals.delete_many(remove)
            if delete_result.deleted_count > 0:
                print("Successfully deleted.")
                return True
            else:
                print("Animal does not exist.")
                return False
        else:
            print("Nothing to delete, remove parameter is empty")
            return False


# In[4]:


from AnimalShelter import AnimalShelter
data = {}
lookup + {"animal_id": " "}
test = AnimalShelter()
success = test.create(data)
print(success)
result = test.read(data)
print(result)


# In[ ]:




